<?php
include "../config.php";
include "../libraries/db.php";
$page ="dashboard.php";
if(isset($_GET['p']))
{
	$p = $_GET['p'];
	switch($p)
	{
		case "slideshow":
			$page = "slideshow.php";
			break;
		case "product":
			$page = "product.php";
			break;
		case "category":
			$page = "category.php";
			break;
		case "user":
			$page = "user.php";
			break;
		case "configuration":
			$page = "configuration.php";
			break;	
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<!-- head -->
<?php include "includess/head.php" ?>
<!-- head -->
<body>
	<div class="wrapper">
		<!-- nav -->
		<?php include "includess/nav.php" ?>
		<!-- nav -->

		<div class="main">
		<!-- header	 -->
		<?php include "includess/header.php" ?>
		<!-- header	 -->

			<!-- dashboard -->
			<?php include $page; ?>
			<!-- dashboard -->

		<!-- footer	 -->
		<?php include "includess/footer.php"?>
		<!-- footer	 -->
		</div>
	</div>
	<!-- foort or js -->
	<?php include "includess/foot.php"?>
	<!-- foort or js -->

</body>

</html>