<?php
$result = dbSelect("tbl_slideshow","*","","order by ssorder asc");
?>
<main class="content">
	<div class="container-fluid p-0">
         <h1 class="h3 mb-3">slideshow<h1/>
		 <table class="table">
			<tr>
				<th>No</th>
				<th>Image</th>
				<th>Title</th>
				<th>Subtitle</th>
				<th>Text</th>
				<th>Link</th>
				<th>Action</th>
			</tr>
			<?php
			    $i=1;
			    while($row=mysqli_fetch_array(($result)))
				{
			?>
			<tr>
				<td><?=$i?></td>
				<td><img src="../images/home/<?=$row['img']?>" style="width:50px"/></td>
				<td><?=$row['title']?></td>
				<td><?=$row['subtitle']?></td>
				<td><?=$row['text']?></td>
				<td><?=$row['link']?></td>
				<td>
					<a href="#"><i data-feather="arrow-up"></i></a>
					<a href="#"><i data-feather="arrow-down"></i></a>
					<a href="#"><i data-feather="eye"></i></a>
					<a href="#"><i data-feather="trash"></i></a>
					<a href="#"><i data-feather="edit"></i></a>
				</td>
			</tr>
			<?php
			    $i++;
			    }
			?>
		 </table>
	</div>
</main>