<?php
     include "config.php";
	 include "libraries/db.php";
     $page = "home.php";
	 $slider = true;
	 $sidebar = true;
	 if (isset($_GET['p']))
	 {
		$p = $_GET['p'];
		switch($p)
		{
			case "shop":
				$page = "shop.php";
				$slider = false;
				break;
			case "contact":
				$page= "contact.php";
				$slider = false;
				$sidebar = false;
				break;
		}
	 }
?>
<!DOCTYPE html>
<html lang="en">
	<!--/head-->
	<?php  include "includes/head.php" ?>
	<!--/head-->
<body>
	<!--/header-->
	<?php  include "includes/header.php" ?>
	<!--/header-->
	<!--/slider-->
	<?php 
	if ($slider)
	    include "includes/slider.php";
	?>
	<!--/slider-->
	<section>
		<div class="container">
			<div class="row">
			<!--/sidebar-->
			<?php 
			    if ($sidebar)
			     include "includes/sidebar.php";
				?>
			<!--/sidebar-->
			
			<!--/home-->
			<?php include $page; ?>
			<!--/home-->
			</div>
		</div>
	</section>
	<!-- footer -->
	<?php include "includes/footer.php"?> 
	<!-- footer -->
</body>
</html>